package ru.calculator.misc;

public enum RomanNumber {
    I,II,III,IV,V,VI,VII,VIII,IX,X
}
